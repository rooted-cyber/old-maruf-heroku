# Strings Analytics


| Code | Language | Translated | Remaining |
|----|-------|-------|---|
| en | English [English] | 418 | 0 |
| ar | Arabic [العربية] | 418 | NULL |
| si | sinhala [සිංහල] | 112 | 306 |
| hi | Hindi [हिंदी] | 413 | 5 |
| fr | French [Français] | 110 | 308 |
| jp | Japanese [日本] | 413 | 5 |
| fa | Persian [Farsi] | 391 | 27 |
| id | Indonesia [Indonesia] | 413 | 5 |
| pt-br | Portuguese [Português] | 413 | 5 |
| gu | Gujarati [ગુજરાતી] | 109 | 309 |
| ml | Malayalam [മലയാളം] | 112 | 306 |
| ru | Russian [Русский] | 413 | 5 |
| ta | தமிழ் [தமிழ்] | 112 | 306 |
| my | Malay [Bahasa Melayu] | 112 | 306 |
| es | Spanish [Español] | 409 | 9 |
| od | Odia [ଓଡିଆ] | 112 | 306 |
| tr | Turkish [Türk] | 112 | 306 |
| mr | Marathi [मराठी] | 131 | 287 |
| cn | Chinese [简体中文] | 112 | 306 |
| ka | Kannada [ಕನ್ನಡ] | 112 | 306 |
| bn | Bengali [বাংলা] | 382 | 36 |
| it | Italian [italiano] | 111 | 307 |
| az | Azerbaijan [Azərbaycan] | 382 | 36 |


If Strings are not present, Google Translation will be used to Translate them at time of Usage.
<br>• Remaining Strings can be found [here](./remaining.csv) for easy sort out.